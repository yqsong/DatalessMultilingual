
WALS Online data download
=========================

Data of WALS Online is published under the following license:
http://creativecommons.org/licenses/by/4.0/

It should be cited as

Dryer, Matthew S. & Haspelmath, Martin (eds.) 2013.
The World Atlas of Language Structures Online.
Leipzig: Max Planck Institute for Evolutionary Anthropology.
(Available online at http://wals.info, Accessed on 2015-07-30.)

